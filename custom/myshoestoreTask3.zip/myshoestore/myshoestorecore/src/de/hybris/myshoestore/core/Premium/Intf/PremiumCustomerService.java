package de.hybris.myshoestore.core.Premium.Intf;

import de.hybris.myshoestore.core.model.PremiumCustomerModel;

import java.util.List;

public interface PremiumCustomerService {

    public List<PremiumCustomerModel>getPremiumCustomerDetails();
}
