package de.hybris.myshoestore.core.Premium.Intf;


import de.hybris.myshoestore.core.model.PremiumCustomerModel;

import java.util.List;

public interface PremiumCustomerDao {

    public List<PremiumCustomerModel>getPremiumCustomerDetails();

}
