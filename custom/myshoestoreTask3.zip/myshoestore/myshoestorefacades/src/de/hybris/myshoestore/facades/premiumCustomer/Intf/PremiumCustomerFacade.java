package de.hybris.myshoestore.facades.premiumCustomer.Intf;
import de.hybris.myshoestore.facades.PremiumCustomerData;
import java.util.List;
public interface PremiumCustomerFacade {
    public List<PremiumCustomerData>getPremiumCustomerDetails();
}