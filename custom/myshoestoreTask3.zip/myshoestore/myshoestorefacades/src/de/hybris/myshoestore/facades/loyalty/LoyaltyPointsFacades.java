package de.hybris.myshoestore.facades.loyalty;

import de.hybris.myshoestore.facades.LoyaltyData;

public interface LoyaltyPointsFacades
{
	public LoyaltyData defaultLoyaltyPointsFacade();
}
